<template>
  <div>
    <VueSyntax1 />
    <!-- <VueSyntax2/> -->
    <!-- <VueSyntax3/> -->
    <!-- <VueSyntax4/> -->
  </div>
</template>

<script>
import VueSyntax1 from "@/components/VueSyntax1";
// import VueSyntax2 from "@/components/VueSyntax2";
// import VueSyntax3 from "@/components/VueSyntax3";
// import VueSyntax4 from "@/components/VueSyntax4";
export default {
  components: { // component 등록
    VueSyntax1,
    // VueSyntax2,
    // VueSyntax3
    // VueSyntax4
  },
}
</script>
  