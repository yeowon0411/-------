<template>
<div> Header component </div>
</template>
<style scoped>
div {
height: 80px;
background: burlywood;
padding : 10px ;
border-bottom: 2px solid grey;
}

</style>
