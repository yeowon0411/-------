<template>
    <div> Main component </div>
</template>

<style scoped>
    div {
        flex: 4;
        padding-left: 10px;
        height: 400px; 
        background: blue;
        color: white
    }
</style>