<template>
    <div> Nav component </div>
</template>

<style scoped>
    div {
        flex: 1; 
        height: 400px; 
        background: yellowgreen;
        padding-left: 10px;
    }
</style>
