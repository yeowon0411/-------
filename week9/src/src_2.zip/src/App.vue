<template>
  <div>
    <VueSyn1 />
    <VueSyn2 />
    <VueSyn3 />
    <VueSyn4 />
  </div>
</template>
<script>
import VueSyn1 from "@/components/VueSyn1";
import VueSyn2 from "@/components/VueSyn2";
import VueSyn3 from "@/components/VueSyn3";
import VueSyn4 from "@/components/VueSyn4";
export default {
  components: { // component 등록
    VueSyn1,
    VueSyn2,
    VueSyn3,
    VueSyn4,
  },
}
</script>
  