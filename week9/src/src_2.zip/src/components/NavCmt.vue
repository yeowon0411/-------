<template>
    <nav>
        <ol>
            <li> <a href="/">html</a> </li>
            <li> <a href="/">css</a> </li>
            <li> <a href="/">js</a> </li>
        </ol>
    </nav>
</template>