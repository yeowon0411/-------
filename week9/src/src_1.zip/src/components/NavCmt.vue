<template>
    <nav>
         <ol>
            <li> <a href="/">html</a> </li>
            <li> <a href="/">css</a> </li>
            <li> <a href="/">js</a> </li>
            </ol>
        </nav>
</template>
<style scoped>
nav {
    flex: 1;
    height: 400px;
    background-color: lightgreen;
    padding-left: 10px;
}

a {
    text-decoration: none;
}
</style>
    