<template>
    <div>
        <h1>My Page</h1>
    </div>
</template>