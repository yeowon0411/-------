<template>
    <div>
              <h1>About page</h1>
              <p> 새로운 페이지 입니다</p>
          </div>
</template>
    